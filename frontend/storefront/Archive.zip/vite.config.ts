import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5173,
    proxy: {
      // Flask backend runs on :5000 in dev; matches the /api/* routes from the LLD.
      '/api': 'http://localhost:5000',
    },
  },
})
